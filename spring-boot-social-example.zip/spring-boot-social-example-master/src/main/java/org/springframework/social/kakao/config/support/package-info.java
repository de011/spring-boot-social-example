/**
 * 
 */
/**
 * @author bonggi.seo
 *
 */
package org.springframework.social.kakao.config.support;