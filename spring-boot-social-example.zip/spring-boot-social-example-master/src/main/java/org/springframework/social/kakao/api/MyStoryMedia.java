package org.springframework.social.kakao.api;

public class MyStoryMedia {
	private String original;
	private String xlarge;
	private String large;
	private String medium;
	private String small;
	public String getOriginal() {
		return original;
	}
	public String getXlarge() {
		return xlarge;
	}
	public String getLarge() {
		return large;
	}
	public String getMedium() {
		return medium;
	}
	public String getSmall() {
		return small;
	}
	MyStoryMedia(){}
}
