/**
 * 
 */
/**
 * @author bonggi.seo
 *
 */
package org.springframework.social.kakao.connect;