package org.springframework.social.kakao.api;

public class MyStoryWriter {
	private String display_name;
	private String profile_thumbnail_url;
	public String getDisplay_name() {
		return display_name;
	}
	public String getProfile_thumbnail_url() {
		return profile_thumbnail_url;
	}
	MyStoryWriter() {}
}
